function y=norm_mtx(x,len,n)
% Function to obtain correlation matrix
x1 = reshape([x(:);zeros(mod(-numel(x),n),1)],n,[]);
m=len/n;
B=0;
for i=1:n
    for k=1:n
        B(i,k)=calc(i,k,x1,m); 
    end
end
%[R,P] = corrcoef(B)
y=B;


