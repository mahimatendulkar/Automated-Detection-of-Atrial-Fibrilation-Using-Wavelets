function [Bbar] = normalized_corrmatrix(seg)

 mm=size(seg,2);    

  n=size(seg,1);

     for i=1:n

         for j=1:n

               k=1;

%                for tou=(-mm+1):1:(mm-1)

%                    

%                    

%                    Bd(k)=(1./mm)*sum(seg(i,:).*circshift(seg(j,:), tou));

%                    

%                    k=k+1;

%                    

%                end

                Bd=xcorr(seg(i,:),seg(j,:));

               Bbar(i,j)=sum(Bd)./(2*mm-1);

           end

         

     end

         