clc;
close all;
clear all;
clearvars;

feat1=[];
load('N_AF_Exp_data_180_seg_10_second.mat');
inputdata1=AF_seg;
inputdata2=N_seg;

%for ii=1:size(inputdata1,1)

ii=1;
filt = wpdec(inputdata1(ii,:),5,'db4','shannon');

cfs1 = wpcoef(filt,[5 1]);

cfs2 = wpcoef(filt,[5 2]);

    n=15;

    mm=floor(length(cfs1)/n);

    for i=1:n

        seg1(i,:)=cfs1((mm*(i-1)+1):(mm*i));

        seg2(i,:)=cfs2((mm*(i-1)+1):(mm*i));

    end

    [Bbar1] = normalized_corrmatrix(seg1);

    Bbar1=Bbar1.*(Bbar1>0);%try with some changes here

    D1=size(Bbar1,1)*size(Bbar1,1);

    Bbar1=triu(Bbar1);

    [counts1,centers1] =hist(reshape(Bbar1,1,D1,[]),50);

    Wb1=sum(counts1.*centers1);

    Hb1=nansum((counts1./sum(counts1)).*log((counts1./sum(counts1))));

   

    [Bbar2] = normalized_corrmatrix(seg2);

    Bbar2=Bbar2.*(Bbar2>0);%try with some changes here

    Bbar2=triu(Bbar2);

    D2=size(Bbar2,1)*size(Bbar2,1);

    [counts2,centers2] =hist(reshape(Bbar2,1,D2,[]),50);

    Wb2=sum(counts1.*centers1);

    Hb2=nansum((counts1./sum(counts1)).*log((counts1./sum(counts1))));

   

 feat1(ii,1:4)=[Wb1 Wb2 Hb1 Hb2];
feat1(ii,1:4)=[Wb1./sum(cfs1.^2) Wb2./sum(cfs2.^2) Hb1./sum(cfs1.^2) Hb2./sum(cfs2.^2)].*sum(inputdata1(ii,:).^2);
   
%end

data1=[log(abs(feat1))];

% for ii=1:size(inputdata2,1)
% 
% 
% 
% filt = wpdec(inputdata2(ii,:),5,'db4','shannon');
% 
% cfs1 = wpcoef(filt,[5 1]);
% 
% cfs2 = wpcoef(filt,[5 2]);
% 
%     n=15;
% 
%     mm=floor(length(cfs1)/n);
% 
%     for i=1:n
% 
%         seg1(i,:)=cfs1((mm*(i-1)+1):(mm*i));
% 
%         seg2(i,:)=cfs2((mm*(i-1)+1):(mm*i));
% 
%     end
% 
%     [Bbar1] = normalized_corrmatrix(seg1);
% 
%     Bbar1=Bbar1.*(Bbar1>0);%try with some changes here
% 
%     D1=size(Bbar1,1)*size(Bbar1,1);
% 
%     Bbar1=triu(Bbar1);
% 
%     [counts1,centers1] =hist(reshape(Bbar1,1,D1,[]),50);
% 
%     Wb1=sum(counts1.*centers1);
% 
%     Hb1=nansum((counts1./sum(counts1)).*log((counts1./sum(counts1))));
% 
%    
% 
%     [Bbar2] = normalized_corrmatrix(seg2);
% 
%     Bbar2=Bbar2.*(Bbar2>0);%try with some changes here
% 
%     Bbar2=triu(Bbar2);
% 
%     D2=size(Bbar2,1)*size(Bbar2,1);
% 
%     [counts2,centers2] =hist(reshape(Bbar2,1,D2,[]),50);
% 
%     Wb2=sum(counts1.*centers1);
% 
%     Hb2=nansum((counts1./sum(counts1)).*log((counts1./sum(counts1))));
% 
%    
% 
% feat2(ii,1:4)=[Wb1 Wb2 Hb1 Hb2];
% 
% feat2(ii,1:4)=[Wb1./sum(cfs1.^2) Wb2./sum(cfs2.^2) Hb1./sum(cfs1.^2) Hb2./sum(cfs2.^2)].*sum(inputdata2(ii,:).^2);
%    
% end
% 
% data2=[log(abs(feat2))];
% 
% 
% data1(:,1)=ones(225,1);
% data2(:,1)=zeros(225,1);
% % 
% data=[data1;data2];
