% This is the main file for data preparation 
% data_train is the matrix consisting features
% target1 is the matrix consisting targets


clc;
close all;
clear all;
clearvars;

%% for data preparation 
filename='04015m.mat';
Ann_mat1=my_new_code(filename);

filename='04043m.mat';
Ann_mat2=my_new_code(filename);

filename='04048m.mat';
Ann_mat3=my_new_code(filename);
 
filename='04126m.mat';
Ann_mat4=my_new_code(filename);

filename='04746m.mat';
Ann_mat5=my_new_code(filename);

filename='05091m.mat';
Ann_mat6=my_new_code(filename);
% 
filename='05261m.mat';
Ann_mat7=my_new_code(filename);

filename='07859m.mat';
Ann_mat8=my_new_code(filename);

filename='07162m.mat';
Ann_mat9=my_new_code(filename);




 Ann_mat=[Ann_mat1;Ann_mat2;Ann_mat3;Ann_mat4;Ann_mat5;Ann_mat6;Ann_mat7;Ann_mat8;Ann_mat9];

 
 %% For lable generation 
 ecg_ann1=generatelables('afdb/04015');
 ecg_ann2=generatelables('afdb/04043');
 ecg_ann3=generatelables('afdb/04048');
 ecg_ann4=generatelables('afdb/04126');
 ecg_ann5=generatelables('afdb/04746');
 ecg_ann6=generatelables('afdb/05091');
 ecg_ann7=generatelables('afdb/05261');
 ecg_ann8=generatelables('afdb/07859');
 ecg_ann9=generatelables('afdb/07162');



 ecg_ann=[ecg_ann1';ecg_ann2';ecg_ann3';ecg_ann4';ecg_ann5';ecg_ann6';ecg_ann7';ecg_ann8';ecg_ann9'];

  
%% to create targets  
for r=1:length(ecg_ann)
    target(r,1)=ecg_ann(r);
    if ecg_ann(r)==0
    target(r,2)=1;
    end
    if ecg_ann(r)==1
     target(r,2)=0;
    end
end
 
p=0;
q=0;
for i=1:length(ecg_ann)
 if ecg_ann(i)==0
     p=p+1;
     Ann_NSR(p,:)=Ann_mat(i,:);
 end
 if ecg_ann(i)==1
     q=q+1;
     Ann_AF(q,:)=Ann_mat(i,:);
 end
end
%  
data_train=[Ann_NSR(1:size(Ann_AF,1),:);Ann_AF];
target1=[zeros(size(Ann_AF,1),1),ones(size(Ann_AF,1),1);ones(size(Ann_AF,1),1),zeros(size(Ann_AF,1),1)];
% 
% % % 
for i=1:size(Ann_AF)
  Ann_krw(i,1)=Ann_NSR(i,3);
  Ann_krw(i,2)=Ann_AF(i,3);


end
