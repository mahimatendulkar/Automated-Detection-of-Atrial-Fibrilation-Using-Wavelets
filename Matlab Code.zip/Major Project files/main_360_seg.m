% This is the main file for data preparation 
% data_train is the matrix consisting features
% target1 is the matrix consisting targets


% % clc;
% % close all;
% % clear all;
% % clearvars;
% % 
% % % for data preparation 
% % 
%%load('N_AF_Exp_data_180_seg_10_second.mat');

















%% data prep 2020
load mcdata.mat

p1=0;
q1=0;
for i=1:size(mc_labels,1)
    if mc_labels(i)==1
        p1=p1+1;
        AF_seg1{p1,1}=mcdata{i,1};
    end
    if mc_labels(i)==4
        q1=q1+1;
        N_seg1{q1,1}=mcdata{i,1};
    end
end

AF_seg_arr1=horzcat(AF_seg1{:});
N_seg_arr1=horzcat(N_seg1{:});

Ann_mat_AF1=calc_data1(AF_seg_arr1);
Ann_mat_N1=calc_data1(N_seg_arr1);

data_train1=[Ann_mat_N1;Ann_mat_AF1];
target11=[zeros(size(Ann_mat_N1,1),1),ones(size(Ann_mat_N1,1),1);ones(size(Ann_mat_AF1,1),1),zeros(size(Ann_mat_AF1,1),1)];

%% data prep for 2017

% load PhysionetData.mat
% 
% p=0;
% q=0;
% for i=1:size(Labels,1)
%     if Labels(i)=='A'
%         p=p+1;
%         AF_seg{p,1}=Signals{i,1}(1,750:size(Signals{i,1},2));
%     end
%     if Labels(i)=='N'
%         q=q+1;
%         N_seg{q,1}=Signals{i,1}(1,750:size(Signals{i,1},2));
%     end
% end
% AF_seg_arr=horzcat(AF_seg{:});
% N_seg_arr=horzcat(N_seg{:});
%  
% Ann_mat_AF=calc_data(AF_seg_arr);
% Ann_mat_N=calc_data(N_seg_arr);
% data_train=[Ann_mat_N;Ann_mat_AF];
% target1=[zeros(size(Ann_mat_N,1),1),ones(size(Ann_mat_N,1),1);ones(size(Ann_mat_AF,1),1),zeros(size(Ann_mat_AF,1),1)];

% % %% For Kruskalwallis test
for i=1:100
  Ann_krw(i,1)=Ann_mat_AF1(i,4);
  Ann_krw(i,2)=Ann_mat_N1(i,4);
end
% % boxplot(Ann_krw,'labels',{'AF','NSR'})
% % title('HB in Band 52')
