function y=waveletlow(ecg_notch,LoD)
% for r=1:1:2500
%     if mod(r,2)==0
%     dtemp(r)=ecg_notch(r);
%     else
%         dtemp(r)=0;
%     end
% end
sum1=downsample(ecg_notch,2);
% for timi=1:1:2500
%     sum=0;
%     for r=1:1:length(LoD)
%         if (timi-r)>0
%             sum=dtemp(timi-r)*LoD(r)+sum;
%         else
%             sum=sum;
%         end
%     end
%     d(timi)=sum;
% end
y=cconv(LoD,sum1);
%y=d;