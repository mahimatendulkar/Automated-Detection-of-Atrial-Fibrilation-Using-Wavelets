function y=filters(ecg1)
%parameters

f_s=300;
N=length(ecg1);
t=(0:N-1)/f_s;

%plot raw ECG
% figure;
% plot(t,ecg1); title('Raw ECG Data plotting ')             
% xlabel('time')
% ylabel('amplitude')

% notch filter implementation 
w=50/(f_s/2);
bw=w;
[num,den]=iirnotch(w,bw);
ecg_notch=filter(num,den,ecg1);
% figure, 
% N1=length(ecg_notch);
% t1=(0:N1-1)/f_s;
% plot(t1,ecg_notch,'r'); title('Notch Filtered ECG signal ')             
% xlabel('time')
% ylabel('amplitude')

%lowpass Butterworth filter
% fNorm = 30 / (f_s/2);               % normalized cutoff frequency
% [bb,aa] = butter(6, fNorm, 'low');  % 6th order filter
% butterfilt = filter(bb, aa, ecg_notch);
% % figure;
% % plot(butterfilt)
% % title('butterworth') 

% Bandpass filter

% Wide BP
Fhigh = 5;  % highpass frequency [Hz]
Flow = 35;   % low pass frequency [Hz]
Nbut = 10;     % order of Butterworth filter
d_bp= design(fdesign.bandpass('N,F3dB1,F3dB2',Nbut,Fhigh,Flow,f_s),'butter');
[b_bp1,a_bp1] = tf(d_bp);

% Narrow BP
Fhigh = 1;  % highpass frequency [Hz]
Flow = 100;   % low pass frequency [Hz]
Nbut = 10;     % order of Butterworth filter
d_bp= design(fdesign.bandpass('N,F3dB1,F3dB2',Nbut,Fhigh,Flow,f_s),'butter');
[b_bp2,a_bp2] = tf(d_bp);

    signal = filtfilt(b_bp1,a_bp1,ecg_notch);             % filtering narrow
    signal = detrend(signal);                        % detrending (optional)
    signal = signal - mean(signal);
    signal = signal/std(signal);                     % standardizing
    signal = filtfilt(b_bp2,a_bp2,signal);     % filtering wide
    signal = detrend(signal);                  % detrending (optional)
    signal = signal - mean(signal);
    signal = signal/std(signal);        % standardizing

%Baseline Removal
% [e,f]=wavedec(signal,10,'db6');% Wavelet implementation
% g=wrcoef('a',e,f,'db6',8); 
% %figure, plot(g),title('checking the recoefficient output')
% ecg_wave=signal-g; % subtracting 10th level aproximation signal
%                         %from original signal                  
% ecg_smooth=smooth(ecg_wave); % using average filter to remove glitches
                             %to increase the performance of peak detection 
%N1=length(ecg_smooth);
% t1=(0:N1-1)/f_s;
% figure,
% subplot 211 ,plot(t,ecg1),title('Original ecg signal'),ylabel('amplitude')
% xlabel('time')
% subplot 212,plot(t1,ecg_wave,'r'),title('Baseline Removed Ecg signal');
% ylabel('amplitude'),xlabel('time')
% figure,plot(t,ecg1,'r')
% hold on ;
% plot(t1,ecg_wave,'g'),ylabel('amplitude'),xlabel('time')
% title('Filtered ECG signal after wavelet and smooth filter')
% legend('ORIGINAL ECG SIGNAL',' Flitered ECG SIGNAL')
% hold off 
% %% Task 3-a
% [num,den]=wavedec(ecg1,10,'db6');% Wavelet implementation for
%                                 % sampling frequency of 250
% d1=wrcoef('d',num,den,'db6',1); % frequency (62-128)
% d2=wrcoef('d',num,den,'db6',2); % frequency (31-62)
% a1=wrcoef('a',num,den,'db6',1); % frequency (0-62)
% a2=wrcoef('a',num,den,'db6',2); % frequency (0-31)
% figure
% subplot 511, plot(ecg_notch),ylabel('ecg'),xlabel('length')
% legend('Sampling frequency 250')
% title('decomposition for  d1,d2,a1,a2') 
% subplot 512,plot(d1,'r'),ylabel('d1'),xlabel('length')
% legend('freq 62-128')
% subplot 513,plot(d2,'k'),ylabel('d2'),xlabel('length'),legend('freq 31-62')
% subplot 514,plot(a1,'g'),ylabel('a1'),xlabel('length'),legend('freq 0-62')
% subplot 515,plot(a2,'m'),ylabel('a2'),xlabel('length'),legend('freq 0-31')
% %% Task 3-b
% d3=wrcoef('d',num,den,'db6',3); % frequency (15-31)
% d4=wrcoef('d',num,den,'db6',4); % frequency (0-7)
% a3=wrcoef('a',num,den,'db6',3); % frequency (7-15)
% a4=wrcoef('a',num,den,'db6',4); % frequency (0-8)
% figure
% subplot 511, plot(ecg_notch),ylabel('ecg'),xlabel('length')
% legend('Sampling frequency 250')
% title('decomposition  for d3,d4,a3,a4') 
% subplot 512,plot(d3,'r'),ylabel('d3'),xlabel('length'),legend('freq 15-31')
% subplot 513,plot(d4,'k'),ylabel('d4'),xlabel('length'),legend('freq 7-15')
% subplot 514,plot(a3,'g'),ylabel('a3'),xlabel('length'),legend('freq 0-15')
% subplot 515,plot(a4,'m'),ylabel('a4'),xlabel('length'),legend('freq 0-8')
%
%[qrspeaks,locs] = findpeaks(ecg_wave,10,'MinPeakHeight',0.35,...
   % 'MinPeakDistance',0.150)
%    peak=findpeaks(ecg_wave);
%    mean(ecg_wave);
%    mode(ecg_wave);
%    std(ecg_wave);
[locs_Rwave,~] = findpeaks(signal);%,'MinPeakHeight',4,...
                                    %'MinPeakDistance',200);
if min(locs_Rwave)>0
    signal=signal;
else
    signal=-signal;
end
y=signal;

