
%requires wfdb tool to read .atr
function [Y]=generatelables(filename)

[ann, anntype, subtype, chan, num, comments] = rdann(filename,'atr');

%for adjusting samples 
len_ann=length(ann);
ann_mod(1)=1;
for p=1:len_ann
    ann_mod(p+1)=ann(p);
    if p==len_ann
     ann_mod(len_ann+2)=9205000;
    end
end
comments_mod(1)=cellstr('A');
for p=1:len_ann
    comments_mod(p+1)=comments(p);
    if p==len_ann
     comments_mod(len_ann+2)=cellstr('Z');
    end
end


for i=1:length(comments_mod)-1
      c=char(comments_mod(i));
  for s=ann_mod(i):1:ann_mod(i+1)
    switch c
         case '(AFIB'
             ecg_bin(s)=1;
         case '(N'
             ecg_bin(s)=0;
         case '(AFL'
             ecg_bin(s)=0;
         case  '(J'
             ecg_bin(s)=0;
         case 'A'
             ecg_bin(s)=0;
         case 'Z'
             ecg_bin(s)=0;
    end
    
   end
end

ecg_overlap=buffer(ecg_bin,2500,250)';


a=1;
for j=1:size(ecg_overlap,1)
 ecgp=ecg_overlap(j,:);
% for j=0:2500:(2500*400)-1
% ecgp=ecg_bin(j+1:j+2500);
idx=ecgp==0;
out=sum(idx(:));
if out<2000
    ecg_ann(a)=1;
end
if out>=2000
   ecg_ann(a)=0;
end
 a=a+1;
end
Y=ecg_ann;
